/**
 * create by wangzhiyong 
 * date:2017-08-14
 * desc:将下拉组件类型独立
 */
export default [
               "select",//普通下拉
                "date",//日期选择
                "time",//时间选择
                "timerange",//时间范围
                "datetime",//时间选择
                "daterange",//日期范围选择
                "datetimerange",//日期时间范围选择
                "picker",//级联选择组件               
                "treepicker",//下拉树选择
                "muti"//多行添加
            ]