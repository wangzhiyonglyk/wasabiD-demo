/**
 * create by wangzhiyong 
 * date:2017-08-14
 * desc:将文本类型独立
 */
export default [
    "text",//普通输入框
            "textarea",//多行文本
            "password",//密码
            "email",//邮箱
            "url",//网址
            "mobile",//手机
            "idcard",//身份证
            "alpha",//英文字母
            "alphanum",//英文字母与数字
            "integer",//整型数据
            "number",//数字
]