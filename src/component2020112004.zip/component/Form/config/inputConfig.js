/**
 * create by wangzhiyong 
 * date:2017-08-14
 * desc:将表单类型独立
 */
export default [
     "none",//空的占位符
     "rate",//评分
     "text",//普通输入框
     "password",//密码
     "email",//邮箱
     "url",//网址
     "mobile",//手机
     "idcard",//身份证
     "date",//日期
     "time",//时间
     "timerange",//时间范围
     "datetime",//日期时间
     "daterange",//日期范围
     "datetimerange",//日期时间范围
     "alpha",//英文字母
     "alphanum",//英文字母与数字
     "integer",//整型数据
     "number",//数字
     "textarea",//多行文本
     "select",//下拉框
     "radio",//单选框
     "checkbox",//复选框
     "checkbutton",//复选按钮
     "switch",//开关
     "picker",//级联选择组件
     "treepicker",//下拉树选择
     "panelpicker",//面板选择
]