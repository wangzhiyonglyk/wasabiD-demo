//create by wangzy
//date:2016-04-25
//edit 2016-09-27重写
//desc:日期组件，
import React, { Component } from "react";
import PropTypes from "prop-types";

import CalendarHeader from "./CalendarHeader.jsx";
import CalendarBody from "./CalendarBody.jsx";

import("../Sass/Form/DateTime.css");
class DateD extends Component {
    constructor(props) {
        super(props)
        var newDate = new Date();
        var year = (this.formatDate(newDate, 'yyyy'));
        var month = (this.formatDate(newDate, 'MM'));

        this.state = {
            year: this.props.year ? this.props.year : year,
            month: this.props.month ? this.props.month : month,
            day: this.props.day,
            isRange: this.props.isRange,
            min: this.props.min,
            max: this.props.max,
            changeYear: false,//选择年份
            changeMonth: false,//选择月份
        }
        this.updateYearAndMonth=this.updateYearAndMonth.bind(this);
        this.dayHandler=this.dayHandler.bind(this);
        this.formatDate=this.formatDate.bind(this);
    
        this.changeYear=this.changeYear.bind(this);
        this.changeMonth=this.changeMonth.bind(this);
        this.changeYearHandler=this.changeYearHandler.bind(this);
        this.changeMonthHandler=this.changeMonthHandler.bind(this);
    }

    componentWillReceiveProps(nextProps) {
        if (nextProps.isRange == true) {//是日期范围选择，要更新最大值与最小值
            this.setState({
                year: nextProps.year ? nextProps.year : this.state.year,
                month: nextProps.month ? nextProps.month : this.state.month,
                day: nextProps.day,
                isRange: nextProps.isRange,
                min: nextProps.min,
                max: nextProps.max,
            });
        } else {
            this.setState({
                year: nextProps.year ? nextProps.year : this.state.year,
                month: nextProps.month ? nextProps.month : this.state.month,
                day: nextProps.day,
                isRange: nextProps.isRange,
            });
        }

    }

    updateYearAndMonth(filterYear, filterMonth) {
        this.setState({
            year: filterYear,
            month: filterMonth,
            day: null,//清空
            min: null,
            max: null,
        });

        if (this.props.updateYearAndMonth != null) {
            this.props.updateYearAndMonth(filterYear, filterMonth);
        }
    }
    dayHandler(day) {
        this.setState({
            day: day,
            min: day,
            max: day,
        })
        if (this.props.onSelect) {
            let value = this.state.year + "-" + (this.state.month.toString().length == 1 ? "0" + this.state.month.toString() : this.state.month)
                + "-" + (day < 10 ? "0" + day.toString() : day);

            this.props.onSelect(value, value, this.props.name);
        }

    }
    formatDate(date, format) {
        /**
         * 对Date的扩展，将 Date 转化为指定格式的String
         * 月(M)、日(d)、12小时(h)、24小时(H)、分(m)、秒(s)、周(E)、季度(q) 可以用 1-2 个占位符
         * 年(y)可以用 1-4 个占位符，毫秒(S)只能用 1 个占位符(是 1-3 位的数字)
         * eg:
         * Utils.formatDate(new Date(),'yyyy-MM-dd') ==> 2014-03-02
         * Utils.formatDate(new Date(),'yyyy-MM-dd hh:mm') ==> 2014-03-02 05:04
         * Utils.formatDate(new Date(),'yyyy-MM-dd HH:mm') ==> 2014-03-02 17:04
         * Utils.formatDate(new Date(),'yyyy-MM-dd hh:mm:ss.S') ==> 2006-07-02 08:09:04.423
         * Utils.formatDate(new Date(),'yyyy-MM-dd E HH:mm:ss') ==> 2009-03-10 二 20:09:04
         * Utils.formatDate(new Date(),'yyyy-MM-dd EE hh:mm:ss') ==> 2009-03-10 周二 08:09:04
         * Utils.formatDate(new Date(),'yyyy-MM-dd EEE hh:mm:ss') ==> 2009-03-10 星期二 08:09:04
         * Utils.formatDate(new Date(),'yyyy-M-d h:m:s.S') ==> 2006-7-2 8:9:4.18
         */
        if (!date) return;
        var o = {
            "M+": date.getMonth() + 1, //月份
            "d+": date.getDate(), //日
            "h+": (date.getHours() % 12 == 0 ? 12 : date.getHours() % 12), //小时
            "H+": date.getHours(), //小时
            "m+": date.getMinutes(), //分
            "s+": date.getSeconds(), //秒
            "q+": Math.floor((date.getMonth() + 3) / 3), //季度
            "S": date.getMilliseconds() //毫秒
        };
        var week = {
            "0": "\u65e5",
            "1": "\u4e00",
            "2": "\u4e8c",
            "3": "\u4e09",
            "4": "\u56db",
            "5": "\u4e94",
            "6": "\u516d"
        };

        if (/(y+)/.test(format)) {
            format = format.replace(RegExp.$1, (date.getFullYear() + "").substr(4 - RegExp.$1.length));
        }

        if (/(E+)/.test(format)) {
            format = format.replace(RegExp.$1, ((RegExp.$1.length > 1) ? (RegExp.$1.length > 2 ? "\u661f\u671f" : "\u5468") : "") + week[date.getDay() + ""]);
        }
        for (var k in o) {
            if (new RegExp("(" + k + ")").test(format)) {
                format = format.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
            }
        }
        return format;
    }
    changeYear() {
        this.setState({
            changeYear: !this.state.changeYear,
            changeMonth: false,
        })

    }
    changeMonth() {
        this.setState({
            changeYear: false,
            changeMonth: !this.state.changeMonth,
        })
    }
    changeYearHandler(value) {

        this.setState({
            year: value,
            changeYear: false,
            changeMonth: false,
            day: null,//清空
            min: null,
            max: null,
           
        })
    }
    changeMonthHandler(value) {
        this.setState({
            month: value,
            changeYear: false,
            changeMonth: false,
            day: null,//清空
            min: null,
            max: null,
        })
    }

    render() {
       
        return (
            <div className="wasabi-datetime"  >
                <CalendarHeader
                    year={this.state.year}
                    month={this.state.month}
                    updateFilter={this.updateYearAndMonth}
                    changeYear={this.changeYear}
                    changeMonth={this.changeMonth}
                />

                <CalendarBody
                    year={this.state.year}
                    month={this.state.month}
                    day={this.state.day}
                    isRange={this.state.isRange}
                    min={this.state.min}
                    max={this.state.max}
                    dayHandler={this.dayHandler}
                    changeYear={this.state.changeYear}
                    changeMonth={this.state.changeMonth}
                    changeYearHandler={this.changeYearHandler}
                    changeMonthHandler={this.changeMonthHandler}
                />
            </div>
        )
    }
}
DateD.propTypes = {
    name: PropTypes.string,//字段名称，对应于表单
    year: PropTypes.oneOfType([
        PropTypes.number,
        PropTypes.string,
    ]),//年
    month: PropTypes.oneOfType([
        PropTypes.number,
        PropTypes.string,
    ]),//月
    day: PropTypes.oneOfType([
        PropTypes.number,
        PropTypes.string,
    ]),//日
    isRange: PropTypes.bool,//是否为范围选择
    min: PropTypes.oneOfType([
        PropTypes.number,
        PropTypes.string,
    ]),//最小值，用于日期范围选择
    max: PropTypes.oneOfType([
        PropTypes.number,
        PropTypes.string,
    ]),//最大值,用于日期范围选择
    onSelect: PropTypes.func,//选择后的事件


};
DateD.defaultProps = {
    year: null,
    month: null,
    day: null,
    isRange: false,///默认否
    min: null,//默认为空，不属于日期范围选择
    max: null,//默认为空，不属于日期范围选择

};
export default DateD;