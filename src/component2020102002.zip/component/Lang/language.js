/**
 * Created by zhiyongwang on 2016-04-25.
 */
import   en from "./en.js";
import cn  from "./zh-cn.js";

var Lang=
{

    cn:cn,
    en:en


}


export default Lang;