
/**
 * Created by zhiyongwang on 2016-04-25.
 * 英文版
 */
var lang=
{
    SUN: "SUN",
    MON: "MON",
    TUE: "TUE",
    WED: "WED",
    THU: "WED",
    FRI: "FRI",
    SAT: "SAT",
}
export default lang;