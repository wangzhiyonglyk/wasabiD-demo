/**
 * Created by wangzhiyong on 16/8/9.
 * 时间轴数据模型
 */
class TrackModel
{
    constructor(time="",info="") {
this.time=time;
        this.info=info;
    }
}
export default TrackModel;